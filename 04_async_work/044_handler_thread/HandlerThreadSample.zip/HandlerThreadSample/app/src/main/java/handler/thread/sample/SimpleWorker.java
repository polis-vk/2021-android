package handler.thread.sample;

import android.util.Log;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicBoolean;

public class SimpleWorker extends Thread {
    private static final String TAG = "SimpleWorker";

    private final AtomicBoolean isAlive = new AtomicBoolean(true);
    private final ConcurrentLinkedQueue<Runnable> queue = new ConcurrentLinkedQueue<>();

    public SimpleWorker() {
        super(TAG);
        start();
    }

    @Override
    public void run() {
        while (isAlive.get()) {
            Runnable task = queue.poll();
            if (task != null) {
                task.run();
            }
        }
        Log.d(TAG, "Simple Worker Terminated");
    }

    public SimpleWorker execute(Runnable task) {
        queue.add(task);
        return this;
    }

    public void quit() {
        isAlive.set(false);
    }
}

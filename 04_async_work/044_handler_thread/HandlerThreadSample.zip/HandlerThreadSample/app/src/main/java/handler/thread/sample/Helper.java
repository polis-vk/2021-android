package handler.thread.sample;

import android.view.View;
import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ValueAnimator;
import android.animation.ObjectAnimator;
import android.support.annotation.NonNull;
import android.view.animation.BounceInterpolator;

public final class Helper {
    private static final float[] PULSE_VALUES = {1.1f, 1.7f, 2, 2.7f, 3, 2.5f, 2, 1.7f, 1.5f, 1};

    public static Animator pulse(@NonNull final View target) {
        final long delay = new ValueAnimator().getDuration();
        AnimatorSet result = new AnimatorSet();
        result.playTogether(
            ObjectAnimator.ofFloat(target, View.SCALE_X, PULSE_VALUES),
            ObjectAnimator.ofFloat(target, View.SCALE_Y, PULSE_VALUES));
        result.setInterpolator(new BounceInterpolator());
        result.setDuration(5 * delay);
        result.setStartDelay(delay);
        result.start();
        return result;
    }

    public static void unpulse(final Animator pulsing) {
        if (pulsing != null) {
            pulsing.end();
        }
    }

    private Helper() {}
}

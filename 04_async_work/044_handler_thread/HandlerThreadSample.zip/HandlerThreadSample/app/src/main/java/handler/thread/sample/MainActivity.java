package handler.thread.sample;

import android.animation.Animator;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private final Handler handler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            text.setText((String) msg.obj);
            Helper.unpulse(pulsing);
        }
    };

    //private SimpleWorker worker;
    private Worker worker;
    private TextView text;

    private Animator pulsing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text = findViewById(R.id.text);

        pulsing = Helper.pulse(text);

        //worker = new SimpleWorker();
        worker = new Worker();

        worker.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(3000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Message message = Message.obtain();
                message.obj = "Task 1 completed";
                handler.sendMessage(message);
            }
        }).execute(() -> {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Message message = Message.obtain();
            message.obj = "Task 2 completed";
            handler.sendMessage(message);
        }).execute(() -> {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Message message = Message.obtain();
            message.obj = "Task 3 completed";
            handler.sendMessage(message);
        }).execute(() -> {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Message message = Message.obtain();
            message.obj = "Task 4 completed";
            handler.sendMessage(message);
        }).execute(() -> {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Message message = Message.obtain();
            message.obj = "Task 5 completed";
            handler.sendMessage(message);
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Helper.unpulse(pulsing);

        worker.quit();
    }
}
